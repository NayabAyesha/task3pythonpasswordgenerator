import random

pass_lowercase = 'abcdefghijklmnopqrstuvwxyz'
pass_uppercase = pass_lowercase.upper()
pass_numbers = '0123456789'
pass_special_charactors = '!@#$%^&*()-+_={}[]:;"''|?.,<>'

gathering = pass_lowercase + pass_uppercase + pass_numbers + pass_special_charactors
password_length=0
while True:
    try:
        password_length = int(input("Enter the value in integer: "))
        if password_length <= 0:
            print("The value should be greater than zero. ")
        else:
            password = "".join(random.sample(gathering, password_length))
            print("The Generated Password is as " + password)
        break
    except ValueError:
        print("Please enter the valid integer value. ")



